const express=require("express")
const mongoose=require("mongoose")
const router=require("./Routes/bookRoutes")
const books=require('./Routes/bookRoutes')
var cors = require('cors');

const app=express()
let corsAllow={
    origin:"http://localhost:3000",
    methods:"PUT,GET,POST,PATCH,DELETE,HEAD",
    Credential:true
}
app.use(express.json(corsAllow))
app.use(cors());

app.use("/api/firstap1",books)
const PORT=5000;
app.listen(PORT,()=>{
    console.log(`Server is listen at port number ${PORT}`)
})
mongoose.connect("mongodb://localhost:27017/bookmanagementsystem",{

}).then(()=>{
    console.log("db connecton successful")
}).catch((error)=>{
    console.log(error)
})
